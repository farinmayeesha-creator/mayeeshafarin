# Mayeesha Farin Haque — Portfolio Website

A minimal, responsive portfolio website built with plain HTML, CSS, and JavaScript. No coding tools or paid hosting are required. It can be published free with GitHub Pages.

## Files
- `index.html` — all portfolio text and page sections
- `styles.css` — colors, typography, spacing, and responsive layout
- `script.js` — small mobile navigation interaction

## Publish with GitHub Pages
1. Create a free GitHub account at https://github.com.
2. Create a **public** repository named exactly `YOUR-GITHUB-USERNAME.github.io`.
3. Open the repository, choose **Add file → Upload files**, and upload these three website files plus this README.
4. Select **Commit changes**.
5. Open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Choose branch `main` and folder `/ (root)`, then click **Save**.
8. Wait a few minutes. Your site should appear at `https://YOUR-GITHUB-USERNAME.github.io`.

## Personalize before sharing
Open `index.html` in GitHub by clicking its filename, then click the pencil icon to edit. Replace:
- `YOUR-EMAIL@example.com` with your professional email address.
- `YOUR-LINKEDIN` with the final part of your LinkedIn profile URL.
- The three writing sample placeholders with real article titles, short descriptions, and published URLs.
- Any role dates or titles that need correction.

You can also replace the placeholder sample links by editing the relevant `href="#"` value. Keep the quotation marks around URLs.

## Important accuracy check
The traffic and keyword metrics in the Crowdfundly case study are project-level figures shared in the user's work history, not claims that one person or one article alone caused the growth. The portfolio wording intentionally reflects contribution rather than sole ownership. Review the figures, role dates, titles, and placement count before publishing.

## Updating the design
You do not need to edit CSS to publish. If you later want to change the accent colors, open `styles.css` and adjust the color values near the top under `:root`.
